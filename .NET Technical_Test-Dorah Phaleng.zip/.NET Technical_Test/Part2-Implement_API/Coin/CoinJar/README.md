
The coin jar will only accept the latest US coinage and has a volume of 42 fluid ounces. Additionally, the jar has a
counter to keep track of the total amount of money collected and can reset the count back to $0.00.

