using System;
using System.Collections.Generic;

public abstract class Mint
{
	public abstract Coin ManufactureCoinOfValue(int value);
}
