[ApiController]  
 [Route("[controller]")]  
 public class MyControllerController : ControllerBase  
 {  
     private readonly ILogger<CoinController> logger; 
     private readonly CoinJar coinJar;
  
     public MyControllerController(ILogger<CoinController> logger, CoinJar coinJar)  
     {  
         this.logger = logger; 
         this.coinJar = coinJar;
     } 
     [HttpPost]
     public void AddCoin([FromBody]eCoinType coinType, [FromBody]int count = 1)
     {
        this.coinJar.AddCoin(coinType, count);
     }
     [HttpGet]
     public decimal Amount()
     {
        return this.coinJar.GetTotalAmount();
     }
}