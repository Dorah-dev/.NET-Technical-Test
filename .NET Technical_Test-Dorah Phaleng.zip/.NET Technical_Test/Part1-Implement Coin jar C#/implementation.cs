using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Net;  
using System.Net.Http;  
using System.Web.Http;  
  
namespace CoinJarAPI.Controllers  
{  
    public class CoinJarController : ApiController  
    {  
        // GET: api/CoinJar  
        public IEnumerable<string> Get()  
        {  
            return new string[] { "value1", "value2" };  
        }  
  
        // GET: api/CoinJar/5  
        public string Get(int id)  
        {  
            return "value";  
        }  
  
        // POST: api/CoinJar  
        public void Post([FromBody]string value)  
        {  
        }  
  
        // PUT: api/CoinJar/5  
        public void Put(int id, [FromBody]string value)  
        {  
        }  
  
        // DELETE: api/CoinJar/5  
        public void Delete(int id)  
        {  
        }  
    }  
}  
  
  //Section 2

using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Text;  
using System.Threading.Tasks;  
  
namespace CoinJarAPI.Interface  
{  
    interface ICoinJar  
    {  
        void AddCoin(ICoin coin);  
        decimal GetTotalAmount();  
        void Reset();  
    }  
  
    public interface ICoin  
    {  
        decimal Amount { get; set; }  
        decimal Volume { get; set; }  
    }  
}  
  
  //Section 3

using CoinJarAPI.Interface;  
using System;  
using System.Collections.Generic;  
using System.Linq;  
using System.Web;  
  
namespace CoinJarAPI.Repository  
{  
    public class Repository : ICoinJar  
    {  
        public void AddCoin(ICoin coin)  
        {  
            throw new NotImplementedException();  
        }  
  
        public decimal GetTotalAmount()  
        {  
            throw new NotImplementedException();  
        }  
  
        public void Reset()  
        {  
            throw new NotImplementedException();  
        }  
    }  
}  
 
 
