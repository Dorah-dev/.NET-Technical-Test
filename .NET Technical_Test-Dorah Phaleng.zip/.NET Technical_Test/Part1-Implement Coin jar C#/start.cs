public class Startup  
{  
  /* .... */  
  
  
  public void ConfigureServices(IServiceCollection services)  
  {  
  
           services.AddControllersWithViews();  
           services.AddRazorPages();  
  
           // THIS IS IMPORTANT  
           services.AddSingleton<CoinJar>(provider => new CoinJar());  
       }  
  
     /* .... */ 